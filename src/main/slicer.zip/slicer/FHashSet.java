package slicer;

import java.util.HashSet;
import java.util.List;

/* T must be the OneElementSet
 *
 */
public class FHashSet<T> extends HashSet<T> implements Set<T>{
  private static final long serialVersionUID = 1L;
	protected int id = SetFactory.SETID++;
	
	public FHashSet (Set<T> ... elems){
		for(Set<T> set : elems){
			if(set != null){
				for(T t : set){
					this.add(t);
				}
			}
		}
	}
	
	@Override
  public int getID() {
	  return id;
  }

	public int hashCode() {
		return id;
	}
	
	@Override
  public boolean isProcessed() {
		return true;
  }

	@Override
  public boolean contains(Set<T> set1, int depth) {
	  return false;
  }
	@Override
  public FunctionalFlatSet<T> flatten() {
		throw new UnsupportedOperationException();
	}

  @Override
  public void addElements(List<Set<T>> list) {
		throw new UnsupportedOperationException();
  }

	@Override
  public void setProcessed(Boolean value) {
		throw new UnsupportedOperationException();
	}

	@Override
  public boolean isInteresting() {
		throw new UnsupportedOperationException();
  }

	@Override
  public void printSet(int ident) {
		throw new UnsupportedOperationException();
  }

	@Override
  public void resetProcessed() {
		throw new UnsupportedOperationException();
  }

	@Override
  public String getSourceLocation() {
	  throw new UnsupportedOperationException();
  }

	@Override
  public String getSourceMethod() {
		throw new UnsupportedOperationException();
  }

	@Override
  public String getSourceClass() {
		throw new UnsupportedOperationException();
  }


	
}

