package slicer;

import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.MethodInfo;
import gov.nasa.jpf.jvm.bytecode.Instruction;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class OneElementSet<T> implements Set<T> {

	private static final long serialVersionUID = 1L;
	private T elem;
	private final int id = SetFactory.SETID++;
	private boolean instructionHasChanged;

	private String sourceMethod;
	private String sourceClass;

	public OneElementSet(T elem, boolean instructionHasChanged) {
		super();
		if(SetupSlicer.SPL_ON ){
			Instruction insn = JVM.getVM().getLastInstruction();
			MethodInfo minfo = insn.getMethodInfo();
			if(minfo != null && minfo.getClassInfo().getInterest() == 1){
				sourceMethod = minfo.getName();
				sourceClass = minfo.getClassName();
			}
		}
		this.elem = elem;
		this.instructionHasChanged = instructionHasChanged;
	}

	@Override
	public Iterator<T> iterator() {
		return new Iterator<T>() {
			boolean read = false;

			@Override
			public boolean hasNext() {
				boolean result = !read;
				read = true;
				return result;
			}

			@Override
			public T next() {
				return elem;
			}

			@Override
			public void remove() {
				throw new UnsupportedOperationException();
			}
		};
	}

	@Override
	public int getID() {
		return id;
	}

	boolean isProcessed;

	@Override
	public boolean isProcessed() {
		return isProcessed;
	}

	@Override
	public void setProcessed(Boolean value) {
		isProcessed = value;
	}

	@Override
	public void addElements(List<Set<T>> list) {
		list.add(this);
	}

	@Override
	public boolean contains(Set<T> set1, int depth) {
		if (set1 instanceof OneElementSet) {
			if (((OneElementSet<T>) set1).elem == elem || ((OneElementSet<T>) set1).elem.equals(elem)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public FunctionalFlatSet<T> flatten() {
		ArrayList<T> result = new ArrayList<T>();
		result.add(getElem());
		return new FunctionalFlatSet<T>(result);
	}

	public T getElem() {
		return elem;
	}

	public String toString() {
		return this.elem.toString();
	}

	@Override
	public boolean isInteresting() {
		return instructionHasChanged;
	}

	@Override
	public void printSet(int ident) {
		String spaces = "";
		for (int i = 1; i <= ident; i++) {
			spaces = spaces + " ";
		}
		StringBuffer sb = new StringBuffer();
		sb.append(spaces + "--oe_" + getID());
		sb.append("(" + elem + ")");
		System.out.println(sb);
	}

	@Override
	public void resetProcessed() {
		setProcessed(false);
	}

	@Override
	public String getSourceLocation() {
		return this.elem.toString();
	}

	@Override
	public String getSourceMethod() {
		return sourceMethod;
	}

	@Override
	public String getSourceClass() {
		return sourceClass;
	}
	public int hashCode(){
		return id;
	}
}
